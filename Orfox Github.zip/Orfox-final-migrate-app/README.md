This is the final "Migrate to Tor Browser" mini app that replaces Orfox.

See this ticket for more info: https://trac.torproject.org/projects/tor/ticket/29955
